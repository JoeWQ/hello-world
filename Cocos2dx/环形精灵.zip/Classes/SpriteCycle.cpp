//ѭ����������ʵ��
//ע�������ʱ��,��ʱ�뷽��Ϊ��
//2017-1-21 11:54:45
#include"SpriteCycle.h"
#include"renderer/ccGLStateCache.h"
#include"Geometry.h"
#include<math.h>
#define __MATH_PI_    3.14159265358
//Vertex Shader 
static const char *CycleVertexShader = "attribute vec4    a_position;"
"attribute vec2 a_fragCoord;"
"uniform mat4 u_modelViewMatrix;"
"uniform mat4 u_rotateMatrix;"
"uniform mat4 u_projMatrix;"
"varying vec2 v_fragCoord;"
"void	main()"
"{"
"		gl_Position = u_projMatrix * u_modelViewMatrix * u_rotateMatrix*a_position;"
"		v_fragCoord = a_fragCoord;"
"}";
static const char *CycleFragShader = "uniform sampler2D CCTexture;"
"varying vec2 v_fragCoord;"
"void	main()"
"{"
"	gl_FragColor = texture2D(CCTexture,v_fragCoord);"
"}";
MeshCycle::MeshCycle()
{
	_vVertexId = 0;
	_vVertexIndexId = 0;
	_vVertexCount = 0;
	_vVertexIndexCount = 0;
}
MeshCycle::~MeshCycle()
{
	glDeleteBuffers(1, &_vVertexId);
	glDeleteBuffers(1, &_vVertexIndexId);
	_vVertexId = 0;
	_vVertexIndexId = 0;
	_vVertexCount = 0;
}
void MeshCycle::initMeshCycle(float width, float radius, int xGrid, int yGrid)
{
	//�������ж������Ŀ,ע�⻹������������
	int totalCount = (xGrid+1)*(yGrid+1);
	float  *VertexData = new float[totalCount*(3+2)];
	float  xOffset = 0.0f;
	float  yOffset = 0.0f;
	//Բ����ǰ�벿��
	const  int  halfCycle = (yGrid + 1) / 2;
	for (int y = 0; y < yGrid + 1; ++y)//ע��,���ﲻ���õȺ�,��Ϊ���ô��������,������߶�������̱Ƚ���Ϥ,���Լ�
	{
		yOffset = -radius*cos(1.0f*y / halfCycle*__MATH_PI_);
		//ǰ�� 
		float zOffset = radius * sin(1.0f*y / halfCycle*__MATH_PI_);
		float   *Vertex = VertexData + (xGrid + 1)*y *(3+2);
		for (int x = 0; x < xGrid + 1; ++x)//ע��,�������ݺ��������꽻��洢
		{
			const int index = x *(3+2);
			Vertex[index] = width*x/xGrid;
			Vertex[index + 1]=yOffset;
			Vertex[index + 2] = zOffset;
			//ע��png�����ĸ�ʽ����
			Vertex[index + 3] = 1.0*x/xGrid;
			Vertex[index + 4] = 1.0 - 1.0*y / yGrid;
		}
	}
	//����������������
	int  indexCount = xGrid*yGrid*6;
	int  *indexVertx = new int[indexCount];
	for (int i = 0; i < yGrid; ++i)
	{
		for (int j = 0; j < xGrid; ++j)
		{
			const int index = (i * xGrid+j)*6;
			//����������
			indexVertx[index ] = (i+1)*(xGrid+1)+j;
			indexVertx[index + 1] = i*(xGrid + 1) + j;
			indexVertx[index + 2] = (i + 1)*(xGrid + 1) + j+1;

			indexVertx[index + 3] = (i+1)*(xGrid+1)+j+1;
			indexVertx[index + 4] = i*(xGrid+1)+j;
			indexVertx[index + 5] = i*(xGrid+1)+j+1;
		}
	}
	//����OpenGL���㻺��������
	int  defaultVertexId, defaultVertexIndexId;
	glGetIntegerv(GL_ARRAY_BUFFER_BINDING, &defaultVertexId);
	glGetIntegerv(GL_ELEMENT_ARRAY_BUFFER_BINDING, &defaultVertexIndexId);
	glGenBuffers(1, &_vVertexId);
	glBindBuffer(GL_ARRAY_BUFFER, _vVertexId);
	glBufferData(GL_ARRAY_BUFFER, totalCount*sizeof(float)* 5, VertexData, GL_STATIC_DRAW);

	glGenBuffers(1, &_vVertexIndexId);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, _vVertexIndexId);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, indexCount*sizeof(int), indexVertx, GL_STATIC_DRAW);

	glBindBuffer(GL_ARRAY_BUFFER, defaultVertexId);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, defaultVertexIndexId);
	//��¼�¶���,��������Ŀ
	_vVertexCount = totalCount;
	_vVertexIndexCount = indexCount;
	delete VertexData;
	delete indexVertx;
}
MeshCycle *MeshCycle::createMeshCycle(float width, float radius, int xGrid, int yGrid)
{
	MeshCycle  *_Cycle = new MeshCycle();
	_Cycle->initMeshCycle(width, radius, xGrid, yGrid);
	return _Cycle;
}
//draw Cycle
void   MeshCycle::drawMeshCycle(int _VertexLoc,int _FragCoordLoc)
{
	int _defaultBufferId, _defaultIndexBufferId;
	glGetIntegerv(GL_ARRAY_BUFFER_BINDING, &_defaultBufferId);
	glGetIntegerv(GL_ELEMENT_ARRAY_BUFFER_BINDING, &_defaultIndexBufferId);

	glBindBuffer(GL_ARRAY_BUFFER, _vVertexId);
	glEnableVertexAttribArray(_VertexLoc);
	glVertexAttribPointer(_VertexLoc, 3, GL_FLOAT, GL_FALSE, sizeof(float)* 5, NULL);
	glEnableVertexAttribArray(_FragCoordLoc);
	glVertexAttribPointer(_FragCoordLoc, 2, GL_FLOAT, GL_FALSE, sizeof(float)* 5, (void *)(sizeof(float)*3));

	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER,_vVertexIndexId);
	glDrawElements(GL_TRIANGLES, _vVertexIndexCount, GL_UNSIGNED_INT, NULL);
	//resume
	glBindBuffer(GL_ARRAY_BUFFER, _defaultBufferId);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, _defaultIndexBufferId);
	CHECK_GL_ERROR_DEBUG();
}
SpriteCycle::~SpriteCycle()
{
	_cycleTexture->release();
	_meshCycle->release();
	_glProgram->release();
}
void  SpriteCycle::initWithCycle(std::string &fileName)
{
	//����
	_cycleTexture = cocos2d::Director::getInstance()->getTextureCache()->addImage(fileName);
	_cycleTexture->retain();
	//�������
	cocos2d::Size _size = _cycleTexture->getContentSize();
	//����뾶
	_cycleRadius = _size.height / (2.0f*__MATH_PI_);
	_meshCycle = MeshCycle::createMeshCycle(_size.width, _cycleRadius, 4, 64);
	//Create GLProgram
	//ע����ʵ��ʹ�õĹ�����,���ʹ��Shader����,��Ϊ������Ϊ����ʾ,����û��ʹ��
	_glProgram = cocos2d::GLProgram::createWithByteArrays(CycleVertexShader, CycleFragShader);
	_glProgram->retain();
	_modelViewLoc = _glProgram->getUniformLocation("u_modelViewMatrix");
	_rotateLoc = _glProgram->getUniformLocation("u_rotateMatrix");
	_projLoc = _glProgram->getUniformLocation("u_projMatrix");
	_textureLoc = _glProgram->getUniformLocation("CCTexture");

	_positionLoc = _glProgram->getAttribLocation("a_position");
	_fragCoordLoc = _glProgram->getAttribLocation("a_fragCoord");
}
SpriteCycle *SpriteCycle::createWithCycle(std::string &fileName)
{
	SpriteCycle *_cycle = new SpriteCycle();
	_cycle->initWithCycle(fileName);
	return _cycle;
}
//draw function
void SpriteCycle::drawMeshCycle( cocos2d::Mat4 &modelView, uint32_t flag)
{
	Matrix     _identity;
	_identity.rotate(_nowAngle, 1.0f, 0.0f, 0.0f);
	//ע����Ҫ�ۼ����Լ���λ��,������Ҫ������Ȳ���
	int   _isOpenDepthTest = glIsEnabled(GL_DEPTH_TEST);
	if (!_isOpenDepthTest)
		glEnable(GL_DEPTH_TEST);

	cocos2d::Point _nowPoint = this->getPosition();
	_identity.translate(_nowPoint.x, _nowPoint.y, 0);
	int _default_textureId;
	glGetIntegerv(GL_TEXTURE_BINDING_2D, &_default_textureId);
//	int defaultObject;
//	glGetIntegerv(GL_CURRENT_PROGRAM, &defaultObject);
	_glProgram->use();

	glUniformMatrix4fv(_modelViewLoc, 1, GL_FALSE, modelView.m);
	glUniformMatrix4fv(_rotateLoc, 1, GL_FALSE, _identity.pointer());
	//ͶӰ����
	const cocos2d::Mat4 &_projMatrix = cocos2d::Director::getInstance()->getMatrix(cocos2d::MATRIX_STACK_TYPE::MATRIX_STACK_PROJECTION);
	glUniformMatrix4fv(_projLoc, 1, GL_FALSE, _projMatrix.m);

	glActiveTexture(GL_TEXTURE0);
	glBindTexture(GL_TEXTURE_2D, _cycleTexture->getName());
	glUniform1i(_textureLoc, 0);

	_meshCycle->drawMeshCycle(_positionLoc, _fragCoordLoc);
	CHECK_GL_ERROR_DEBUG();
	glBindTexture(GL_TEXTURE_2D, _default_textureId);
	if (!_isOpenDepthTest)
		glDisable(GL_DEPTH_TEST);
}
//
void SpriteCycle::setAngle(float angle)
{
	_nowAngle = angle;
}
void SpriteCycle::visit(cocos2d::Renderer *renderer, const cocos2d::Mat4& transform, uint32_t flags)
{
	if (!_visible)
		return;
	_drawCycleCommand.func = CC_CALLBACK_0(SpriteCycle::drawMeshCycle, this, transform, flags);
	_drawCycleCommand.init(_globalZOrder);
	renderer->addCommand(&_drawCycleCommand);
	Node::visit(renderer, transform, flags);
}